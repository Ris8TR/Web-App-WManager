package com.AloisioUmerto.Tesi.DataHandler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataHandlerApplicationTests {

	@Test
	void contextLoads() {
	}

}
